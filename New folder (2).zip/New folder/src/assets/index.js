import Brackets from './brackets.svg'
import DigitalMarketing from './digital-marketing.svg'
import Sketch from './sketch.svg'
import AppDev from './app-development.svg'

export {
    Brackets,
    DigitalMarketing,
    Sketch,
    AppDev
};